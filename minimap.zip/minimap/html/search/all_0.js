var searchData=
[
  ['map',['map',['../structmap.html',1,'']]],
  ['minimap',['minimap',['../structminimap.html',1,'']]]
];
